import type { NextConfig } from "next";
const config: NextConfig = { transpilePackages: ["@northbound/business"] };
export default config;
