export default function Setup() {
  return (
    <main>
      <h1>NorthBound needs its Supabase keys</h1>
      <div className="card">
        <p>Create <code>apps/web/.env.local</code> from <code>.env.example</code> and set <code>NEXT_PUBLIC_SUPABASE_URL</code> and <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code>, then restart <code>pnpm dev</code>.</p>
        <p className="muted">See README.md, steps 3 to 5. You can still look at the <a href="/demo.html">interface prototype</a>.</p>
      </div>
    </main>
  );
}
