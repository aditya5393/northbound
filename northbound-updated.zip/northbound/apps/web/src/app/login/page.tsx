"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function Login() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(() => (typeof window !== "undefined" && new URLSearchParams(location.search).get("error") ? "Sign-in failed. Please try again." : ""));

  async function signIn() {
    setBusy(true); setError("");
    const { error } = await createClient().auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${location.origin}/auth/callback` },
    });
    if (error) { setError(error.message); setBusy(false); }
  }

  return (
    <main style={{ maxWidth: 420, paddingTop: 80 }}>
      <div className="card" style={{ textAlign: "center", padding: 28 }}>
        <h1 style={{ margin: 0 }}>NorthBound</h1>
        <p className="muted">Sign in with the Google account your company owner invited.</p>
        <button className="btn" onClick={signIn} disabled={busy}>{busy ? "Opening Google..." : "Continue with Google"}</button>
        {error && <p className="r" role="alert">{error}</p>}
      </div>
    </main>
  );
}
