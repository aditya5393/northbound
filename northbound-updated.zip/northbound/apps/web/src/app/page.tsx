import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Dashboard from "@/components/Dashboard";

type Row = Record<string, any>;

export default async function Home() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data: memberships } = await supabase
    .from("memberships")
    .select("role,status,companies(id,name)")
    .eq("status", "active");

  const m = (memberships as Row[] | null)?.[0];

  const signOut = (
    <form action="/auth/signout" method="post">
      <button className="btn alt" type="submit">
        Sign out
      </button>
    </form>
  );

  if (!m || !m.companies) {
    return (
      <main style={{ maxWidth: 520, paddingTop: 60 }}>
        <h1>NorthBound</h1>
        <div className="card">
          <p>
            <b>No company access yet.</b>
          </p>
          <p className="muted">
            You are signed in as <b>{user.email}</b>, but this account has not been invited to a company. Ask your company owner to invite this exact Google email.
          </p>
          <div style={{ marginTop: 16 }}>{signOut}</div>
        </div>
      </main>
    );
  }

  // Fetch initial company records
  const [tripsRes, customersRes, enrollmentsRes, paymentsRes, expensesRes] =
    await Promise.all([
      supabase
        .from("trips")
        .select("id,company_id,name,destination,start_date,end_date,status,capacity")
        .order("start_date", { ascending: false }),
      supabase
        .from("customers")
        .select("id,company_id,full_name,phone,email,notes")
        .order("full_name"),
      supabase
        .from("enrollments")
        .select("id,company_id,trip_id,customer_id,booking_price_paise,discount_paise,booking_status"),
      supabase
        .from("payments")
        .select("id,company_id,enrollment_id,amount_paise,transaction_type,payment_method,reference_number,paid_at,notes")
        .order("paid_at", { ascending: false }),
      supabase
        .from("expenses")
        .select("id,company_id,trip_id,category,vendor_name,description,amount_paise,expense_date")
        .is("voided_at", null)
        .order("expense_date", { ascending: false }),
    ]);

  return (
    <Dashboard
      userEmail={user.email || ""}
      membership={m as any}
      initialTrips={(tripsRes.data as any) || []}
      initialCustomers={(customersRes.data as any) || []}
      initialEnrollments={(enrollmentsRes.data as any) || []}
      initialPayments={(paymentsRes.data as any) || []}
      initialExpenses={(expensesRes.data as any) || []}
    />
  );
}
