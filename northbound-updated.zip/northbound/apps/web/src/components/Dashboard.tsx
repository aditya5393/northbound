"use client";

import { useState } from "react";
import {
  formatINR,
  rupeesToPaise,
  summarizeTrip,
  type Booking,
  type LedgerEntry,
  type PaymentStatus,
} from "@northbound/business";
import { createClient } from "@/lib/supabase/client";

interface Company {
  id: string;
  name: string;
}

interface Membership {
  role: "owner" | "manager" | "staff";
  status: string;
  companies: Company;
}

interface Trip {
  id: string;
  company_id: string;
  name: string;
  destination: string | null;
  start_date: string | null;
  end_date: string | null;
  status: "open" | "completed" | "archived";
  capacity: number | null;
}

interface Customer {
  id: string;
  company_id: string;
  full_name: string;
  phone: string;
  email?: string | null;
  notes?: string | null;
}

interface Enrollment {
  id: string;
  company_id: string;
  trip_id: string;
  customer_id: string;
  booking_price_paise: number;
  discount_paise: number;
  booking_status: "confirmed" | "cancelled";
}

interface Payment {
  id: string;
  company_id: string;
  enrollment_id: string;
  amount_paise: number;
  transaction_type: "payment" | "refund";
  payment_method: string;
  reference_number: string | null;
  paid_at?: string;
  notes?: string | null;
}

interface Expense {
  id: string;
  company_id: string;
  trip_id: string | null;
  category: string;
  vendor_name: string | null;
  description: string | null;
  amount_paise: number;
  expense_date: string;
}

interface DashboardProps {
  userEmail: string;
  membership: Membership;
  initialTrips: Trip[];
  initialCustomers: Customer[];
  initialEnrollments: Enrollment[];
  initialPayments: Payment[];
  initialExpenses: Expense[];
}

export default function Dashboard({
  userEmail,
  membership,
  initialTrips,
  initialCustomers,
  initialEnrollments,
  initialPayments,
  initialExpenses,
}: DashboardProps) {
  const supabase = createClient();
  const company = membership.companies;

  const [trips, setTrips] = useState<Trip[]>(initialTrips);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [enrollments, setEnrollments] = useState<Enrollment[]>(initialEnrollments);
  const [payments, setPayments] = useState<Payment[]>(initialPayments);
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);

  const [selectedTripId, setSelectedTripId] = useState<string>(
    initialTrips[0]?.id || ""
  );
  const [mode, setMode] = useState<"company" | "customers">("company");
  const [view, setView] = useState<string>("home");

  // Modal states
  const [modal, setModal] = useState<
    "newTrip" | "addPerson" | "addExpense" | "recordPayment" | "billStatement" | null
  >(null);
  const [selectedEnrollmentId, setSelectedEnrollmentId] = useState<string | null>(null);
  const [expandedCustomerId, setExpandedCustomerId] = useState<string | null>(null);

  // Form states
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState("");
  const [toastMessage, setToastMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3500);
  };

  const selectedTrip = trips.find((t) => t.id === selectedTripId);

  // Helper calculations for a trip
  const getTripEnrollments = (tripId: string) =>
    enrollments.filter((e) => e.trip_id === tripId);

  const getEnrollmentPayments = (enrollmentId: string) =>
    payments.filter((p) => p.enrollment_id === enrollmentId);

  const getEnrollmentNet = (enrollmentId: string) =>
    getEnrollmentPayments(enrollmentId).reduce(
      (sum, p) => (p.transaction_type === "refund" ? sum - p.amount_paise : sum + p.amount_paise),
      0
    );

  const getEnrollmentDue = (e: Enrollment) => {
    if (e.booking_status === "cancelled") return 0;
    const total = e.booking_price_paise - e.discount_paise;
    return Math.max(0, total - getEnrollmentNet(e.id));
  };

  const getTripBookingsData = (tripId: string) => {
    return getTripEnrollments(tripId).map((e) => ({
      booking: {
        pricePaise: e.booking_price_paise,
        discountPaise: e.discount_paise,
        status: e.booking_status,
      } as Booking,
      entries: getEnrollmentPayments(e.id).map(
        (p): LedgerEntry => ({
          type: p.transaction_type,
          amountPaise: p.amount_paise,
          reference: p.reference_number,
        })
      ),
    }));
  };

  const getTripExpenses = (tripId: string) =>
    expenses.filter((x) => x.trip_id === tripId);

  const currentTripSummary = selectedTripId
    ? summarizeTrip(
        getTripBookingsData(selectedTripId),
        getTripExpenses(selectedTripId).map((x) => x.amount_paise)
      )
    : null;

  // Handlers
  async function handleCreateTrip(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setFormError("");
    const form = new FormData(e.currentTarget);
    const name = (form.get("name") as string)?.trim();
    const destination = (form.get("destination") as string)?.trim();
    const startDate = (form.get("start_date") as string) || null;
    const endDate = (form.get("end_date") as string) || null;
    const capacityVal = form.get("capacity") as string;
    const capacity = capacityVal ? parseInt(capacityVal, 10) : null;

    if (!name) {
      setFormError("Trip name is required.");
      setBusy(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from("trips")
        .insert({
          company_id: company.id,
          name,
          destination: destination || null,
          start_date: startDate,
          end_date: endDate,
          capacity: capacity && capacity > 0 ? capacity : null,
          status: "open",
        })
        .select()
        .single();

      if (error) throw error;
      setTrips([data, ...trips]);
      setSelectedTripId(data.id);
      setModal(null);
      showToast(`Trip "${name}" created successfully.`);
    } catch (err: any) {
      setFormError(err.message || "Failed to create trip.");
    } finally {
      setBusy(false);
    }
  }

  async function handleAddPerson(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedTripId) {
      setFormError("Please select a trip first.");
      return;
    }
    setBusy(true);
    setFormError("");
    const form = new FormData(e.currentTarget);
    const fullName = (form.get("full_name") as string)?.trim();
    let phoneInput = (form.get("phone") as string)?.replace(/\D/g, "");
    if (phoneInput?.startsWith("91") && phoneInput.length === 12) {
      phoneInput = phoneInput.slice(2);
    }
    const priceStr = form.get("price") as string;
    const discStr = (form.get("discount") as string) || "0";

    if (!fullName) {
      setFormError("Please enter full name.");
      setBusy(false);
      return;
    }
    if (!/^[6-9]\d{9}$/.test(phoneInput)) {
      setFormError("Enter a valid 10-digit Indian mobile number (starting with 6, 7, 8, or 9).");
      setBusy(false);
      return;
    }

    let pricePaise: number;
    let discPaise: number;
    try {
      pricePaise = rupeesToPaise(priceStr);
      discPaise = rupeesToPaise(discStr);
      if (pricePaise <= 0) throw new Error("Price must be greater than zero.");
      if (discPaise < 0 || discPaise > pricePaise) {
        throw new Error("Discount must be between ₹0 and the booking price.");
      }
    } catch (err: any) {
      setFormError(err.message || "Invalid rupee amount.");
      setBusy(false);
      return;
    }

    try {
      // 1. Find or create customer
      let cust = customers.find((c) => c.phone === phoneInput);
      if (!cust) {
        const { data: newCust, error: custErr } = await supabase
          .from("customers")
          .insert({
            company_id: company.id,
            full_name: fullName,
            phone: phoneInput,
          })
          .select()
          .single();
        if (custErr) throw custErr;
        cust = newCust;
        setCustomers([...customers, newCust]);
      }

      // 2. Check if already enrolled in this trip
      const alreadyEnrolled = enrollments.some(
        (en) => en.trip_id === selectedTripId && en.customer_id === cust!.id
      );
      if (alreadyEnrolled) {
        throw new Error(`${cust.full_name} is already enrolled on this trip.`);
      }

      // 3. Create enrollment
      const { data: newEnr, error: enrErr } = await supabase
        .from("enrollments")
        .insert({
          company_id: company.id,
          trip_id: selectedTripId,
          customer_id: cust.id,
          booking_price_paise: pricePaise,
          discount_paise: discPaise,
          booking_status: "confirmed",
        })
        .select()
        .single();
      if (enrErr) throw enrErr;

      setEnrollments([newEnr, ...enrollments]);
      setModal(null);
      showToast(`${fullName} enrolled successfully.`);
    } catch (err: any) {
      setFormError(err.message || "Failed to add person.");
    } finally {
      setBusy(false);
    }
  }

  async function handleRecordPayment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedEnrollmentId) return;
    setBusy(true);
    setFormError("");

    const form = new FormData(e.currentTarget);
    const amountStr = form.get("amount") as string;
    const method = (form.get("method") as string) || "upi";
    const ref = (form.get("reference") as string)?.trim() || "";
    const notes = (form.get("notes") as string)?.trim() || "";

    let amountPaise: number;
    try {
      amountPaise = rupeesToPaise(amountStr);
      if (amountPaise <= 0) throw new Error("Amount must be greater than zero.");
    } catch (err: any) {
      setFormError(err.message || "Invalid rupee amount.");
      setBusy(false);
      return;
    }

    try {
      const { data: paymentId, error } = await supabase.rpc("record_payment", {
        p_enrollment_id: selectedEnrollmentId,
        p_amount_paise: amountPaise,
        p_type: "payment",
        p_method: method.toLowerCase().replace(/\s+/g, "_"),
        p_reference: ref || null,
        p_idempotency_key: `pay_${selectedEnrollmentId}_${Date.now()}`,
        p_notes: notes || null,
      });

      if (error) throw error;

      // Re-fetch payments for this enrollment to get fresh state
      const { data: updatedPayments, error: fetchErr } = await supabase
        .from("payments")
        .select("*")
        .eq("company_id", company.id);

      if (!fetchErr && updatedPayments) {
        setPayments(updatedPayments);
      }

      setModal(null);
      showToast(`Payment of ₹${amountStr} recorded successfully.`);
    } catch (err: any) {
      setFormError(err.message || "Payment recording failed.");
    } finally {
      setBusy(false);
    }
  }

  async function handleAddExpense(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selectedTripId) {
      setFormError("Please select a trip first.");
      return;
    }
    setBusy(true);
    setFormError("");

    const form = new FormData(e.currentTarget);
    const category = form.get("category") as string;
    const vendor = (form.get("vendor") as string)?.trim();
    const amountStr = form.get("amount") as string;
    const expenseDate = (form.get("date") as string) || new Date().toISOString().slice(0, 10);

    let amountPaise: number;
    try {
      amountPaise = rupeesToPaise(amountStr);
      if (amountPaise <= 0) throw new Error("Amount must be greater than zero.");
    } catch (err: any) {
      setFormError(err.message || "Invalid rupee amount.");
      setBusy(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from("expenses")
        .insert({
          company_id: company.id,
          trip_id: selectedTripId,
          category: category.toLowerCase().replace(/\s+/g, "_"),
          vendor_name: vendor || null,
          amount_paise: amountPaise,
          expense_date: expenseDate,
        })
        .select()
        .single();

      if (error) throw error;
      setExpenses([data, ...expenses]);
      setModal(null);
      showToast(`Expense for ${vendor || category} recorded.`);
    } catch (err: any) {
      setFormError(err.message || "Failed to record expense.");
    } finally {
      setBusy(false);
    }
  }

  // Active view navigation definitions
  const NAV_ITEMS = {
    company: [
      { id: "home", label: "Home", icon: "🏠" },
      { id: "exp", label: "Expenditure", icon: "🚐" },
      { id: "money", label: "Money", icon: "💰" },
      { id: "hist", label: "History", icon: "📅" },
    ],
    customers: [
      { id: "ppl", label: "Enrolled", icon: "👥" },
      { id: "bill", label: "Billing", icon: "💳" },
      { id: "paid", label: "Bills & Receipts", icon: "🧾" },
    ],
  };

  const currentTripExpenses = selectedTripId ? getTripExpenses(selectedTripId) : [];
  const currentTripEnrollments = selectedTripId ? getTripEnrollments(selectedTripId) : [];

  return (
    <div>
      {/* Header */}
      <header>
        <div className="logo">
          <i>N</i>NorthBound
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ textAlign: "right", fontSize: 13 }}>
            <b>{company.name}</b>
            <div className="muted">{userEmail} ({membership.role})</div>
          </div>
          <form action="/auth/signout" method="post">
            <button className="btn alt" type="submit" style={{ minHeight: 36, padding: "6px 12px", fontSize: 13 }}>
              Sign out
            </button>
          </form>
        </div>
      </header>

      {/* Top Segmented Controls */}
      <div className="top-controls">
        <div className="seg">
          <button
            className={mode === "company" ? "on" : ""}
            onClick={() => {
              setMode("company");
              setView("home");
            }}
          >
            Company Management
          </button>
          <button
            className={mode === "customers" ? "on" : ""}
            onClick={() => {
              setMode("customers");
              setView("ppl");
            }}
          >
            Customers & Billing
          </button>
        </div>

        {/* Trip Selector Bar */}
        <div className="tbar">
          <select
            value={selectedTripId}
            onChange={(e) => {
              setSelectedTripId(e.target.value);
            }}
            aria-label="Select Trip"
          >
            {trips.length === 0 ? (
              <option value="">No trips available</option>
            ) : (
              trips.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} {t.destination ? `(${t.destination})` : ""} - {t.status}
                </option>
              ))
            )}
          </select>

          {membership.role !== "staff" && (
            <button
              className="sec"
              onClick={() => {
                setFormError("");
                setModal("newTrip");
              }}
            >
              + New Trip
            </button>
          )}

          {selectedTripId && (
            <button
              className="sec"
              onClick={() => {
                setFormError("");
                setModal("billStatement");
              }}
            >
              Print Statements
            </button>
          )}
        </div>
      </div>

      {/* Main Layout Container */}
      <div className="wrap">
        {/* Navigation Sidebar */}
        <nav>
          {NAV_ITEMS[mode].map((item) => (
            <button
              key={item.id}
              className={view === item.id ? "on" : ""}
              onClick={() => setView(item.id)}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        {/* Content View Area */}
        <main>
          {/* VIEW: HOME */}
          {view === "home" && (
            <div>
              <div className="head">
                <h1>{selectedTrip?.name || "Trip Overview"}</h1>
                {selectedTrip && (
                  <span className="pill g">Status: {selectedTrip.status}</span>
                )}
              </div>

              {!selectedTrip ? (
                <div className="card" style={{ textAlign: "center", padding: 32 }}>
                  <p><b>No trips created yet.</b></p>
                  <p className="muted">Get started by creating your first tour or expedition.</p>
                  {membership.role !== "staff" && (
                    <button className="pri" onClick={() => setModal("newTrip")}>
                      + Create First Trip
                    </button>
                  )}
                </div>
              ) : currentTripSummary ? (
                <>
                  <div className="kpis">
                    <div className="card">
                      <div className="k">Enrolled Travelers</div>
                      <div className="v">{currentTripSummary.enrolled}</div>
                      <div className="k">{currentTripSummary.peopleWhoPaid} paid in full or partial</div>
                    </div>
                    <div className="card">
                      <div className="k">Payments Received</div>
                      <div className="v g">{formatINR(currentTripSummary.received)}</div>
                      <div className="k">Remaining Due: <b className="a">{formatINR(currentTripSummary.outstanding)}</b></div>
                    </div>
                    <div className="card">
                      <div className="k">{currentTripSummary.profit < 0 ? "Trip Loss" : "Trip Profit"}</div>
                      <div className={`v ${currentTripSummary.profit < 0 ? "r" : "g"}`}>
                        {formatINR(Math.abs(currentTripSummary.profit))}
                      </div>
                      <div className="k">Revenue {formatINR(currentTripSummary.revenue)} minus expenses {formatINR(currentTripSummary.expenses)}</div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="head" style={{ marginBottom: 8 }}>
                      <b>Trip Summary &amp; Dates</b>
                      {selectedTrip.start_date && (
                        <span className="muted">
                          {selectedTrip.start_date} {selectedTrip.end_date ? `to ${selectedTrip.end_date}` : ""}
                        </span>
                      )}
                    </div>
                    <p className="muted" style={{ margin: 0 }}>
                      Destination: {selectedTrip.destination || "Not specified"} | Capacity: {selectedTrip.capacity ? `${currentTripSummary.enrolled}/${selectedTrip.capacity} seats` : `${currentTripSummary.enrolled} enrolled`}
                    </p>
                  </div>
                </>
              ) : null}
            </div>
          )}

          {/* VIEW: EXPENDITURE */}
          {view === "exp" && (
            <div>
              <div className="head">
                <h1>Trip Expenditure</h1>
                {membership.role !== "staff" && selectedTripId && (
                  <button className="pri" onClick={() => { setFormError(""); setModal("addExpense"); }}>
                    + Add Expense
                  </button>
                )}
              </div>

              {!selectedTripId ? (
                <div className="card muted">Please select or create a trip first.</div>
              ) : (
                <>
                  <div className="card">
                    <b>Recorded Expenses for {selectedTrip?.name}</b>
                    <p className="muted" style={{ fontSize: 13 }}>
                      Total Expenses: <b className="r">{formatINR(currentTripExpenses.reduce((s, x) => s + x.amount_paise, 0))}</b>
                    </p>

                    {currentTripExpenses.length === 0 ? (
                      <p className="muted">No expenses recorded for this trip yet.</p>
                    ) : (
                      currentTripExpenses.map((x) => (
                        <div key={x.id} className="row">
                          <div>
                            <b style={{ textTransform: "capitalize" }}>{x.category.replace(/_/g, " ")}</b>
                            {x.vendor_name ? ` — ${x.vendor_name}` : ""}
                            <br />
                            <span className="k">{x.expense_date}</span>
                          </div>
                          <b className="r">{formatINR(x.amount_paise)}</b>
                        </div>
                      ))
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* VIEW: MONEY / FINANCIALS */}
          {view === "money" && (
            <div>
              <div className="head">
                <h1>Financial Health</h1>
              </div>

              {!selectedTripId || !currentTripSummary ? (
                <div className="card muted">Please select or create a trip first.</div>
              ) : (
                <>
                  <div className="kpis">
                    <div className="card">
                      <div className="k">Total Received</div>
                      <div className="v g">{formatINR(currentTripSummary.received)}</div>
                      <div className="k">{currentTripSummary.peopleWhoPaid} paying customers</div>
                    </div>
                    <div className="card">
                      <div className="k">Pending Receivables</div>
                      <div className="v a">{formatINR(currentTripSummary.outstanding)}</div>
                      <div className="k">Awaiting collection</div>
                    </div>
                    <div className="card">
                      <div className="k">Trip Expenses</div>
                      <div className="v">{formatINR(currentTripSummary.expenses)}</div>
                      <div className="k">Operating costs</div>
                    </div>
                    <div className="card">
                      <div className="k">Net Profit / Margin</div>
                      <div className={`v ${currentTripSummary.profit < 0 ? "r" : "g"}`}>
                        {formatINR(currentTripSummary.profit)}
                      </div>
                      <div className="k">Recognized revenue - expenses</div>
                    </div>
                  </div>

                  <div className="card">
                    <b>Cashflow Comparison</b>
                    <div style={{ marginTop: 12 }}>
                      <div className="row" style={{ border: 0, padding: 0 }}>
                        <span>Customer Revenue: <b>{formatINR(currentTripSummary.revenue)}</b></span>
                      </div>
                      <div className="bar">
                        <b style={{ width: `${Math.min(100, (currentTripSummary.received / Math.max(1, currentTripSummary.revenue)) * 100)}%` }}></b>
                      </div>
                    </div>

                    <div style={{ marginTop: 16 }}>
                      <div className="row" style={{ border: 0, padding: 0 }}>
                        <span>Trip Expenses: <b>{formatINR(currentTripSummary.expenses)}</b></span>
                      </div>
                      <div className="bar">
                        <b className="x" style={{ width: `${Math.min(100, (currentTripSummary.expenses / Math.max(1, currentTripSummary.revenue)) * 100)}%` }}></b>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* VIEW: HISTORY */}
          {view === "hist" && (
            <div>
              <div className="head">
                <h1>All Trips History</h1>
              </div>

              {trips.length === 0 ? (
                <div className="card muted">No trips found.</div>
              ) : (
                <div className="card wrap-x">
                  <table>
                    <thead>
                      <tr>
                        <th>Trip</th>
                        <th>Dates</th>
                        <th>Enrolled</th>
                        <th>Revenue</th>
                        <th>Received</th>
                        <th>Pending</th>
                        <th>Expenses</th>
                        <th>Profit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {trips.map((t) => {
                        const summary = summarizeTrip(
                          getTripBookingsData(t.id),
                          getTripExpenses(t.id).map((x) => x.amount_paise)
                        );
                        return (
                          <tr key={t.id}>
                            <td>
                              <b>{t.name}</b>
                              {t.destination && <div className="k">{t.destination}</div>}
                            </td>
                            <td className="k">{t.start_date || "-"}</td>
                            <td>{summary.enrolled}</td>
                            <td>{formatINR(summary.revenue)}</td>
                            <td className="g">{formatINR(summary.received)}</td>
                            <td className="a">{formatINR(summary.outstanding)}</td>
                            <td>{formatINR(summary.expenses)}</td>
                            <td className={summary.profit < 0 ? "r" : "g"}>
                              {formatINR(summary.profit)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* VIEW: ENROLLED PEOPLE */}
          {view === "ppl" && (
            <div>
              <div className="head">
                <h1>Enrolled People</h1>
                {membership.role !== "staff" && selectedTripId && (
                  <button className="pri" onClick={() => { setFormError(""); setModal("addPerson"); }}>
                    + Enroll Customer
                  </button>
                )}
              </div>

              {!selectedTripId ? (
                <div className="card muted">Please select or create a trip first.</div>
              ) : (
                <>
                  <input
                    type="search"
                    placeholder="Search enrolled customer by name or phone..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    style={{ width: "100%", marginBottom: 14 }}
                  />

                  <div className="cols">
                    {currentTripEnrollments
                      .filter((e) => {
                        const cust = customers.find((c) => c.id === e.customer_id);
                        if (!cust) return false;
                        const q = searchQuery.toLowerCase();
                        return (
                          cust.full_name.toLowerCase().includes(q) ||
                          cust.phone.includes(q)
                        );
                      })
                      .map((e) => {
                        const cust = customers.find((c) => c.id === e.customer_id);
                        const net = getEnrollmentNet(e.id);
                        const due = getEnrollmentDue(e);
                        const total = e.booking_price_paise - e.discount_paise;
                        const isExpanded = expandedCustomerId === e.id;

                        return (
                          <div
                            key={e.id}
                            className="card"
                            style={{ cursor: "pointer" }}
                            onClick={() =>
                              setExpandedCustomerId(isExpanded ? null : e.id)
                            }
                          >
                            <div className="row" style={{ paddingTop: 0 }}>
                              <div>
                                <b>{cust?.full_name || "Unknown"}</b>
                                <div className="k">+91 {cust?.phone}</div>
                              </div>
                              <span
                                className={`pill ${due === 0 ? "g" : net === 0 ? "r" : "a"}`}
                              >
                                {due === 0 ? "Paid" : net === 0 ? "Unpaid" : "Partial"}
                              </span>
                            </div>

                            <div style={{ marginTop: 8 }}>
                              <div className="k">Booking Price: {formatINR(e.booking_price_paise)}</div>
                              {e.discount_paise > 0 && (
                                <div className="k">Discount: -{formatINR(e.discount_paise)}</div>
                              )}
                              <div className="row" style={{ border: 0, padding: "6px 0 0" }}>
                                <span>Paid: <b className="g">{formatINR(net)}</b></span>
                                <span>Due: <b className="a">{formatINR(due)}</b></span>
                              </div>
                            </div>

                            {isExpanded && (
                              <div style={{ marginTop: 12, borderTop: "1px solid var(--line)", paddingTop: 10 }}>
                                <b>Payment History:</b>
                                {getEnrollmentPayments(e.id).length === 0 ? (
                                  <p className="k" style={{ margin: "4px 0" }}>No payments recorded yet.</p>
                                ) : (
                                  getEnrollmentPayments(e.id).map((p) => (
                                    <div key={p.id} className="row" style={{ padding: "4px 0", fontSize: 13 }}>
                                      <span>
                                        {p.payment_method?.toUpperCase()}
                                        {p.reference_number ? ` (${p.reference_number})` : ""}
                                      </span>
                                      <b className={p.transaction_type === "refund" ? "r" : "g"}>
                                        {p.transaction_type === "refund" ? "-" : "+"}
                                        {formatINR(p.amount_paise)}
                                      </b>
                                    </div>
                                  ))
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>

                  {currentTripEnrollments.length === 0 && (
                    <div className="card muted" style={{ textAlign: "center", padding: 24 }}>
                      No one is enrolled on this trip yet. Click "+ Enroll Customer" to add participants.
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* VIEW: BILLING & PAYMENT COLLECTION */}
          {view === "bill" && (
            <div>
              <div className="head">
                <h1>Collection &amp; Billing</h1>
              </div>

              {!selectedTripId ? (
                <div className="card muted">Please select or create a trip first.</div>
              ) : currentTripEnrollments.length === 0 ? (
                <div className="card muted">No enrollments on this trip to collect payments from.</div>
              ) : (
                currentTripEnrollments.map((e) => {
                  const cust = customers.find((c) => c.id === e.customer_id);
                  const net = getEnrollmentNet(e.id);
                  const due = getEnrollmentDue(e);
                  const total = e.booking_price_paise - e.discount_paise;
                  const pct = total > 0 ? Math.min(100, Math.round((net / total) * 100)) : 100;
                  const history = getEnrollmentPayments(e.id);

                  return (
                    <div key={e.id} className="card">
                      <div className="row" style={{ paddingTop: 0 }}>
                        <div>
                          <b>{cust?.full_name}</b>
                          <span className="muted" style={{ marginLeft: 8 }}>+91 {cust?.phone}</span>
                        </div>
                        <span className={`pill ${due === 0 ? "g" : net === 0 ? "r" : "a"}`}>
                          {due === 0 ? "Paid in Full" : net === 0 ? "Unpaid" : "Partial"}
                        </span>
                      </div>

                      <div className="bar">
                        <b style={{ width: `${pct}%` }}></b>
                      </div>

                      <div className="row" style={{ border: 0, padding: "4px 0" }}>
                        <span>Collected: <b className="g">{formatINR(net)}</b> ({pct}%)</span>
                        <span>Balance Due: <b className="a">{formatINR(due)}</b></span>
                      </div>

                      {/* Payment actions & history */}
                      <div style={{ marginTop: 12, borderTop: "1px solid var(--line)", paddingTop: 10 }}>
                        <div className="head" style={{ marginBottom: 6 }}>
                          <span className="k">Transactions ({history.length})</span>
                          {due > 0 && membership.role !== "staff" && (
                            <button
                              className="pri"
                              style={{ minHeight: 34, padding: "4px 12px", fontSize: 13 }}
                              onClick={() => {
                                setSelectedEnrollmentId(e.id);
                                setFormError("");
                                setModal("recordPayment");
                              }}
                            >
                              + Record Payment
                            </button>
                          )}
                        </div>

                        {history.map((p) => (
                          <div key={p.id} className="row" style={{ fontSize: 13, padding: "6px 0" }}>
                            <div>
                              <b>{p.payment_method?.toUpperCase()}</b>
                              {p.reference_number ? ` • Ref: ${p.reference_number}` : ""}
                              {p.notes ? ` • ${p.notes}` : ""}
                            </div>
                            <b className={p.transaction_type === "refund" ? "r" : "g"}>
                              {p.transaction_type === "refund" ? "-" : "+"}
                              {formatINR(p.amount_paise)}
                            </b>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* VIEW: PAID BILLS & RECEIPTS */}
          {view === "paid" && (
            <div>
              <div className="head">
                <h1>Settled Bills &amp; Receipts</h1>
                <button className="pri" onClick={() => window.print()}>
                  Print / Save PDF
                </button>
              </div>

              {!selectedTripId ? (
                <div className="card muted">Please select a trip first.</div>
              ) : (
                currentTripEnrollments
                  .filter((e) => getEnrollmentDue(e) === 0 && e.booking_price_paise > 0)
                  .map((e) => {
                    const cust = customers.find((c) => c.id === e.customer_id);
                    const net = getEnrollmentNet(e.id);
                    const paymentsList = getEnrollmentPayments(e.id);

                    return (
                      <div key={e.id} className="paper">
                        <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "2px solid #0b1b33", paddingBottom: 8 }}>
                          <div>
                            <b style={{ fontSize: 20 }}>{company.name}</b>
                            <br />
                            <small>Official Booking Receipt</small>
                          </div>
                          <div style={{ textAlign: "right" }}>
                            <b>RECEIPT</b>
                            <br />
                            <small>Trip: {selectedTrip?.name}</small>
                          </div>
                        </div>

                        <p style={{ margin: "14px 0 8px" }}>
                          <b>Customer:</b> {cust?.full_name} (+91 {cust?.phone})
                          <br />
                          <b>Destination:</b> {selectedTrip?.destination || "Tour Expedition"}
                        </p>

                        <div className="pr">
                          <span>Booking Package Price</span>
                          <b>{formatINR(e.booking_price_paise)}</b>
                        </div>
                        {e.discount_paise > 0 && (
                          <div className="pr">
                            <span>Special Discount</span>
                            <b>-{formatINR(e.discount_paise)}</b>
                          </div>
                        )}
                        <div className="pr">
                          <span>Total Amount Paid</span>
                          <b className="g">{formatINR(net)}</b>
                        </div>
                        <div className="pr" style={{ fontSize: 16 }}>
                          <b>Remaining Balance Due</b>
                          <b>₹0</b>
                        </div>

                        <div style={{ marginTop: 12 }}>
                          <small><b>Payment Transactions:</b></small>
                          {paymentsList.map((p) => (
                            <div key={p.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#475569", marginTop: 4 }}>
                              <span>{p.payment_method.toUpperCase()} {p.reference_number ? `(${p.reference_number})` : ""}</span>
                              <span>+{formatINR(p.amount_paise)}</span>
                            </div>
                          ))}
                        </div>

                        <div className="stamp">PAID</div>
                      </div>
                    );
                  })
              )}

              {currentTripEnrollments.filter((e) => getEnrollmentDue(e) === 0 && e.booking_price_paise > 0).length === 0 && (
                <div className="card muted" style={{ textAlign: "center", padding: 24 }}>
                  No fully paid bookings yet for this trip. Once customer dues reach zero, official receipts with the PAID stamp will appear here.
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* MODAL: NEW TRIP */}
      {modal === "newTrip" && (
        <div className="ov on" onClick={(e) => { if (e.target === e.currentTarget) setModal(null); }}>
          <div className="sheet">
            <div className="head">
              <h2>Create New Trip</h2>
              <button className="ib" onClick={() => setModal(null)}>✕</button>
            </div>
            <form onSubmit={handleCreateTrip}>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <label className="k">Trip Name *</label>
                  <input name="name" placeholder="e.g. Spiti Valley Expedition 2026" required style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div>
                  <label className="k">Destination</label>
                  <input name="destination" placeholder="e.g. Spiti, Himachal Pradesh" style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <div style={{ flex: 1 }}>
                    <label className="k">Start Date</label>
                    <input type="date" name="start_date" style={{ width: "100%", marginTop: 4 }} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label className="k">End Date</label>
                    <input type="date" name="end_date" style={{ width: "100%", marginTop: 4 }} />
                  </div>
                </div>
                <div>
                  <label className="k">Seat Capacity</label>
                  <input type="number" name="capacity" min="1" placeholder="e.g. 15" style={{ width: "100%", marginTop: 4 }} />
                </div>
                {formError && <p className="r" style={{ margin: 0 }}>{formError}</p>}
                <button className="pri" type="submit" disabled={busy} style={{ marginTop: 8 }}>
                  {busy ? "Creating..." : "Save Trip"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ENROLL CUSTOMER */}
      {modal === "addPerson" && (
        <div className="ov on" onClick={(e) => { if (e.target === e.currentTarget) setModal(null); }}>
          <div className="sheet">
            <div className="head">
              <h2>Enroll Customer in {selectedTrip?.name}</h2>
              <button className="ib" onClick={() => setModal(null)}>✕</button>
            </div>
            <form onSubmit={handleAddPerson}>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <label className="k">Full Name *</label>
                  <input name="full_name" placeholder="Customer full name" required style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div>
                  <label className="k">Mobile Number (10 digits) *</label>
                  <input name="phone" type="tel" placeholder="e.g. 9876543210" required style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <div style={{ flex: 1 }}>
                    <label className="k">Booking Price (₹) *</label>
                    <input type="number" step="0.01" min="1" name="price" placeholder="e.g. 45000" required style={{ width: "100%", marginTop: 4 }} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label className="k">Discount (₹)</label>
                    <input type="number" step="0.01" min="0" name="discount" placeholder="0" defaultValue="0" style={{ width: "100%", marginTop: 4 }} />
                  </div>
                </div>
                {formError && <p className="r" style={{ margin: 0 }}>{formError}</p>}
                <button className="pri" type="submit" disabled={busy} style={{ marginTop: 8 }}>
                  {busy ? "Enrolling..." : "Complete Enrollment"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: RECORD PAYMENT */}
      {modal === "recordPayment" && (
        <div className="ov on" onClick={(e) => { if (e.target === e.currentTarget) setModal(null); }}>
          <div className="sheet">
            <div className="head">
              <h2>Record Payment</h2>
              <button className="ib" onClick={() => setModal(null)}>✕</button>
            </div>
            <form onSubmit={handleRecordPayment}>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <label className="k">Amount in Rupees (₹) *</label>
                  <input name="amount" type="number" step="0.01" min="1" placeholder="e.g. 20000" required style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div>
                  <label className="k">Payment Method *</label>
                  <select name="method" defaultValue="upi" style={{ width: "100%", marginTop: 4 }}>
                    <option value="upi">UPI (GPay / PhonePe / Paytm)</option>
                    <option value="cash">Cash</option>
                    <option value="bank_transfer">Bank Transfer (NEFT / IMPS)</option>
                    <option value="card">Card</option>
                    <option value="cheque">Cheque</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="k">Reference Number / UTR</label>
                  <input name="reference" placeholder="e.g. UPI-1234567890" style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div>
                  <label className="k">Notes (Optional)</label>
                  <input name="notes" placeholder="e.g. Advance installment" style={{ width: "100%", marginTop: 4 }} />
                </div>
                {formError && <p className="r" style={{ margin: 0 }}>{formError}</p>}
                <button className="pri" type="submit" disabled={busy} style={{ marginTop: 8 }}>
                  {busy ? "Recording..." : "Record Payment in Ledger"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD EXPENSE */}
      {modal === "addExpense" && (
        <div className="ov on" onClick={(e) => { if (e.target === e.currentTarget) setModal(null); }}>
          <div className="sheet">
            <div className="head">
              <h2>Add Trip Expense</h2>
              <button className="ib" onClick={() => setModal(null)}>✕</button>
            </div>
            <form onSubmit={handleAddExpense}>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <label className="k">Expense Category *</label>
                  <select name="category" defaultValue="hotels" style={{ width: "100%", marginTop: 4 }}>
                    <option value="hotels">Hotels</option>
                    <option value="vehicles">Vehicles &amp; Cabs</option>
                    <option value="camps">Camps</option>
                    <option value="food">Food &amp; Dining</option>
                    <option value="activities">Activities</option>
                    <option value="permits">Permits &amp; Entry</option>
                    <option value="other_facilities">Other Facilities</option>
                    <option value="miscellaneous">Miscellaneous</option>
                  </select>
                </div>
                <div>
                  <label className="k">Vendor Name</label>
                  <input name="vendor" placeholder="e.g. Palm Resort / Himalayan Cabs" style={{ width: "100%", marginTop: 4 }} />
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <div style={{ flex: 1 }}>
                    <label className="k">Amount in ₹ *</label>
                    <input type="number" step="0.01" min="1" name="amount" placeholder="e.g. 15000" required style={{ width: "100%", marginTop: 4 }} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label className="k">Expense Date</label>
                    <input type="date" name="date" defaultValue={new Date().toISOString().slice(0, 10)} style={{ width: "100%", marginTop: 4 }} />
                  </div>
                </div>
                {formError && <p className="r" style={{ margin: 0 }}>{formError}</p>}
                <button className="pri" type="submit" disabled={busy} style={{ marginTop: 8 }}>
                  {busy ? "Saving..." : "Save Expense"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PRINT STATEMENTS */}
      {modal === "billStatement" && (
        <div className="ov on" onClick={(e) => { if (e.target === e.currentTarget) setModal(null); }}>
          <div className="sheet" style={{ maxWidth: 700 }}>
            <div className="head">
              <h2>Print Statements ({selectedTrip?.name})</h2>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="pri" onClick={() => window.print()}>Print / Save PDF</button>
                <button className="ib" onClick={() => setModal(null)}>✕</button>
              </div>
            </div>

            <div style={{ marginTop: 10 }}>
              {currentTripEnrollments.map((e) => {
                const cust = customers.find((c) => c.id === e.customer_id);
                const net = getEnrollmentNet(e.id);
                const due = getEnrollmentDue(e);
                const isPaid = due === 0 && e.booking_price_paise > 0;

                return (
                  <div key={e.id} className="paper">
                    <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "2px solid #0b1b33", paddingBottom: 8 }}>
                      <div>
                        <b style={{ fontSize: 18 }}>{company.name}</b>
                        <br />
                        <small>Booking Statement</small>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <b>{isPaid ? "PAID IN FULL" : "PAYMENT DUE"}</b>
                        <br />
                        <small>{selectedTrip?.name}</small>
                      </div>
                    </div>
                    <p style={{ margin: "10px 0" }}>
                      <b>Customer:</b> {cust?.full_name} (+91 {cust?.phone})
                    </p>
                    <div className="pr">
                      <span>Package Price</span>
                      <b>{formatINR(e.booking_price_paise)}</b>
                    </div>
                    {e.discount_paise > 0 && (
                      <div className="pr">
                        <span>Discount</span>
                        <b>-{formatINR(e.discount_paise)}</b>
                      </div>
                    )}
                    <div className="pr">
                      <span>Total Paid</span>
                      <b className="g">{formatINR(net)}</b>
                    </div>
                    <div className="pr" style={{ fontSize: 16 }}>
                      <b>Amount Due</b>
                      <b className={due > 0 ? "a" : "g"}>{formatINR(due)}</b>
                    </div>
                    {isPaid && <div className="stamp">PAID</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Message */}
      {toastMessage && <div className="toast">{toastMessage}</div>}
    </div>
  );
}
