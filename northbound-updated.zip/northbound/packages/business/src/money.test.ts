import { describe, expect, it } from "vitest";
import { bookingTotal, formatINR, isDuplicate, isPaidInFull, netReceived, outstanding, paymentStatus, recognizedRevenue, rupeesToPaise, summarizeTrip, validateEntry, type Booking, type LedgerEntry } from "./money";

const b = (price: number, discount = 0, status: Booking["status"] = "confirmed"): Booking => ({ pricePaise: price * 100, discountPaise: discount * 100, status });
const pay = (r: number, ref?: string): LedgerEntry => ({ type: "payment", amountPaise: r * 100, reference: ref });
const refund = (r: number, ref?: string): LedgerEntry => ({ type: "refund", amountPaise: r * 100, reference: ref });

describe("money basics", () => {
  it("parses rupees without float drift", () => {
    expect(rupeesToPaise("0.1")).toBe(10);
    expect(rupeesToPaise("19.99")).toBe(1999);
    expect(rupeesToPaise("1,23,456.5")).toBe(12345650);
    expect(() => rupeesToPaise("12.345")).toThrow();
    expect(() => rupeesToPaise("-5")).toThrow();
  });
  it("rejects non-integer paise", () => { expect(() => netReceived([{ type: "payment", amountPaise: 10.5 }])).toThrow(); });
  it("formats INR in Indian grouping", () => { expect(formatINR(12345600)).toBe("₹1,23,456"); });
});

describe("booking ledger", () => {
  it("partial then multiple payments reach paid", () => {
    const book = b(45000), e = [pay(20000)];
    expect(paymentStatus(book, e)).toBe("partial");
    expect(outstanding(book, e)).toBe(25000 * 100);
    e.push(pay(25000));
    expect(isPaidInFull(book, e)).toBe(true);
  });
  it("discount reduces the booking total", () => {
    expect(bookingTotal(b(45000, 2000))).toBe(43000 * 100);
    expect(isPaidInFull(b(45000, 2000), [pay(43000)])).toBe(true);
    expect(() => bookingTotal(b(1000, 2000))).toThrow();
  });
  it("unpaid booking is never paid-in-full, and a zero-price booking is not stamped", () => {
    expect(paymentStatus(b(1000), [])).toBe("unpaid");
    expect(isPaidInFull(b(0), [])).toBe(false);
  });
  it("blocks overpayment", () => {
    expect(validateEntry(b(1000), [pay(900)], pay(200)).ok).toBe(false);
    expect(validateEntry(b(1000), [pay(900)], pay(100)).ok).toBe(true);
  });
  it("refund lowers net received and reopens the balance", () => {
    const book = b(1000), e = [pay(1000)];
    expect(validateEntry(book, e, refund(1500)).ok).toBe(false);
    e.push(refund(300));
    expect(netReceived(e)).toBe(700 * 100);
    expect(outstanding(book, e)).toBe(300 * 100);
    expect(isPaidInFull(book, e)).toBe(false);
  });
  it("cancellation: owes nothing, revenue is only what was kept", () => {
    const c = b(1000, 0, "cancelled");
    expect(outstanding(c, [pay(400)])).toBe(0);
    expect(recognizedRevenue(c, [pay(400)])).toBe(400 * 100);
    expect(recognizedRevenue(c, [pay(400), refund(400)])).toBe(0);
    expect(validateEntry(c, [pay(400)], pay(100)).ok).toBe(false);
    expect(paymentStatus(c, [])).toBe("cancelled");
  });
  it("detects duplicate entries by type, amount and reference", () => {
    expect(isDuplicate([pay(100, "UPI-1")], pay(100, "UPI-1"))).toBe(true);
    expect(isDuplicate([pay(100, "UPI-1")], pay(100, "UPI-2"))).toBe(false);
    expect(isDuplicate([pay(100)], pay(100))).toBe(false);
    expect(validateEntry(b(1000), [pay(100, "X")], pay(100, "X")).ok).toBe(false);
  });
  it("rejects zero or negative amounts", () => {
    expect(validateEntry(b(1000), [], pay(0)).ok).toBe(false);
    expect(validateEntry(b(1000), [], { type: "payment", amountPaise: -5 }).ok).toBe(false);
  });
});

describe("trip summaries", () => {
  const trip1 = [{ booking: b(45000), entries: [pay(45000)] }, { booking: b(45000, 2000), entries: [pay(22000)] }, { booking: b(45000, 0, "cancelled"), entries: [pay(15000), refund(15000)] }];
  const trip2 = [{ booking: b(38000), entries: [pay(15000)] }, { booking: b(38000), entries: [] }];
  it("keeps revenue, cash and outstanding separate", () => {
    const s = summarizeTrip(trip1, [28000 * 100, 31000 * 100]);
    expect(s.enrolled).toBe(2);
    expect(s.revenue).toBe(88000 * 100);
    expect(s.received).toBe(67000 * 100);
    expect(s.outstanding).toBe(21000 * 100);
    expect(s.expenses).toBe(59000 * 100);
    expect(s.profit).toBe(29000 * 100);
    expect(s.peopleWhoPaid).toBe(2);
  });
  it("multiple trips do not leak into each other", () => {
    const a = summarizeTrip(trip1, []), c = summarizeTrip(trip2, [10000 * 100]);
    expect(c.revenue).toBe(76000 * 100);
    expect(c.received).toBe(15000 * 100);
    expect(c.profit).toBe(66000 * 100);
    expect(a.revenue + c.revenue).toBe(164000 * 100);
  });
  it("shows a loss when expenses exceed revenue", () => {
    expect(summarizeTrip([{ booking: b(1000), entries: [] }], [5000 * 100]).profit).toBe(-4000 * 100);
  });
});
