/**
 * NorthBound financial rules. All money is an integer number of paise (1 INR = 100 paise).
 * Accounting assumptions (also in docs/accounting.md):
 *  - Booking value = price - discount. It is NOT cash collected.
 *  - Net received = sum(payments) - sum(refunds).
 *  - Confirmed booking: outstanding = booking value - net received (negative = overpaid, which is blocked on entry).
 *  - Cancelled booking: nothing more is owed (outstanding = 0) and recognized revenue = net amount the company kept
 *    (0 if fully refunded). Cancellation fees are modelled simply as "money kept".
 *  - Trip profit = recognized revenue - expenses assigned to that trip. Company-wide expenses are NOT allocated to trips.
 */
export type Paise = number;
export type EntryType = "payment" | "refund";
export type BookingStatus = "confirmed" | "cancelled";
export interface Booking { pricePaise: Paise; discountPaise: Paise; status: BookingStatus }
export interface LedgerEntry { type: EntryType; amountPaise: Paise; reference?: string | null }
export type PaymentStatus = "unpaid" | "partial" | "paid" | "overpaid" | "cancelled";

export function assertPaise(n: number, label = "amount"): void {
  if (!Number.isSafeInteger(n)) throw new RangeError(`${label} must be a whole number of paise`);
}

/** Parses "1234.50" or 1234.5 rupees to paise without floating-point drift. Throws on bad input. */
export function rupeesToPaise(input: string | number): Paise {
  const s = String(input).trim().replace(/,/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(s)) throw new RangeError("Enter a valid rupee amount with at most 2 decimals");
  const [whole = "0", frac = ""] = s.split(".");
  return Number(whole) * 100 + Number(frac.padEnd(2, "0"));
}

export function formatINR(paise: Paise): string {
  assertPaise(paise);
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(paise / 100);
}

export function bookingTotal(b: Booking): Paise {
  assertPaise(b.pricePaise, "price"); assertPaise(b.discountPaise, "discount");
  if (b.pricePaise < 0 || b.discountPaise < 0 || b.discountPaise > b.pricePaise) throw new RangeError("Discount must be between 0 and the price");
  return b.pricePaise - b.discountPaise;
}

export function netReceived(entries: LedgerEntry[]): Paise {
  return entries.reduce((s, e) => { assertPaise(e.amountPaise); return s + (e.type === "refund" ? -e.amountPaise : e.amountPaise); }, 0);
}

export function recognizedRevenue(b: Booking, entries: LedgerEntry[]): Paise {
  return b.status === "cancelled" ? Math.max(0, netReceived(entries)) : bookingTotal(b);
}

/** Signed: positive = still owed, 0 = settled, negative = overpaid. Cancelled bookings owe nothing. */
export function outstanding(b: Booking, entries: LedgerEntry[]): Paise {
  return b.status === "cancelled" ? 0 : bookingTotal(b) - netReceived(entries);
}

export function paymentStatus(b: Booking, entries: LedgerEntry[]): PaymentStatus {
  if (b.status === "cancelled") return "cancelled";
  const o = outstanding(b, entries), net = netReceived(entries);
  if (o < 0) return "overpaid";
  if (o === 0 && bookingTotal(b) > 0) return "paid";
  return net > 0 ? "partial" : "unpaid";
}

/** True only when the real ledger balance is zero. The PAID stamp must depend on this, never on a flag. */
export const isPaidInFull = (b: Booking, e: LedgerEntry[]) => paymentStatus(b, e) === "paid";

export type Validation = { ok: true } | { ok: false; reason: string };

export function validateEntry(b: Booking, entries: LedgerEntry[], c: LedgerEntry): Validation {
  if (!Number.isSafeInteger(c.amountPaise) || c.amountPaise <= 0) return { ok: false, reason: "Amount must be greater than zero." };
  if (c.type === "payment") {
    if (b.status === "cancelled") return { ok: false, reason: "Cancelled bookings cannot take payments." };
    const o = outstanding(b, entries);
    if (c.amountPaise > o) return { ok: false, reason: "Payment is more than the remaining balance (overpayment blocked)." };
  } else if (c.amountPaise > netReceived(entries)) {
    return { ok: false, reason: "Refund is more than the net amount received." };
  }
  if (isDuplicate(entries, c)) return { ok: false, reason: "This looks like a duplicate entry (same type, amount and reference)." };
  return { ok: true };
}

export function isDuplicate(entries: LedgerEntry[], c: LedgerEntry): boolean {
  const ref = c.reference?.trim();
  return !!ref && entries.some(e => e.type === c.type && e.amountPaise === c.amountPaise && e.reference?.trim() === ref);
}

export interface TripBooking { booking: Booking; entries: LedgerEntry[] }
export interface TripSummary { enrolled: number; peopleWhoPaid: number; revenue: Paise; received: Paise; outstanding: Paise; expenses: Paise; profit: Paise }

export function summarizeTrip(bookings: TripBooking[], tripExpensesPaise: Paise[]): TripSummary {
  const active = bookings.filter(x => x.booking.status === "confirmed");
  const revenue = bookings.reduce((s, x) => s + recognizedRevenue(x.booking, x.entries), 0);
  const received = bookings.reduce((s, x) => s + netReceived(x.entries), 0);
  const owed = active.reduce((s, x) => s + Math.max(0, outstanding(x.booking, x.entries)), 0);
  const expenses = tripExpensesPaise.reduce((s, a) => { assertPaise(a, "expense"); return s + a; }, 0);
  return { enrolled: active.length, peopleWhoPaid: bookings.filter(x => netReceived(x.entries) > 0).length, revenue, received, outstanding: owed, expenses, profit: revenue - expenses };
}
