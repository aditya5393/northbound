# Google sign-in setup (Supabase Auth)

The app code is already written (`apps/web/src/app/login`, `auth/callback`, `middleware.ts`). You only configure the providers.
Menu names in Google and Supabase change now and then; if something differs, follow Supabase docs: "Login with Google".

1. **Supabase**: create a project. Copy the Project URL and the public `anon`/publishable key (Project Settings > API) into `apps/web/.env.local`. Never use the `service_role` key in this app.
2. **Google Cloud Console** (console.cloud.google.com): create a project, configure the OAuth consent screen (External), then Credentials > Create credentials > OAuth client ID > Web application.
   - Authorized redirect URI: `https://<your-project-ref>.supabase.co/auth/v1/callback`
3. **Supabase > Authentication > Providers > Google**: enable it and paste the Client ID and Client secret from step 2.
4. **Supabase > Authentication > URL Configuration**: set Site URL to `http://localhost:3000` for now and add Redirect URLs `http://localhost:3000/**` and later `https://<your-vercel-domain>/**`.
5. Run `docs/provisioning.sql` (edited) so your Google email is invited as owner, then sign in.

How access works: signing in with Google only proves who you are. `/auth/callback` calls the database function `accept_pending_invitations()`, which creates a membership only if an invitation exists for that verified email. Anyone else sees "No company access yet".
