-- ONE-TIME: create your company and invite YOURSELF as the first owner.
-- Run in Supabase Dashboard > SQL Editor AFTER the migration. Edit the two values below first.
-- Nobody becomes an owner just by signing in with Google: access only comes from an invitation for that exact email.
with c as (
  insert into public.companies (name) values ('NorthBound Travels')      -- <- your company name
  returning id
)
insert into public.invitations (company_id, email, role)
select id, lower('you@gmail.com'), 'owner' from c;                       -- <- the Google email you will sign in with
