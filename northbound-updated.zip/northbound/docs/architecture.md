# Architecture
Monorepo (pnpm): `apps/web` (Next.js App Router), `packages/business` (financial rules + tests), `supabase/` (migrations are the source of truth, dev seed, SQL tests).
One backend: Supabase Postgres + Auth (Google) + RLS. The browser only holds the public anon key; there is no service-role key anywhere in client code.
Authorization: identity = Google login; access = `memberships` (company, role, status) enforced by RLS. Roles: owner (everything, invitations), manager (read/write trips, customers, enrollments, expenses, ledger), staff (read only for now). Business tables carry `company_id` with composite foreign keys so a row can never point at another company's trip or customer.

## Built and tested
Schema, RLS, invitations, trusted `record_payment()`, audit log (29 SQL assertions); financial rules (14 unit tests); Google sign-in, session middleware, invitation acceptance, read-only trip dashboard; interface prototype at `/demo.html` (mock data).

## Not built yet (be honest with yourself about scope)
Android/Expo app, trip/customer/enrolment/expense forms wired to the database, PDF generation and document numbering in the real app, reports, per-user theme/widget preferences, `documents` and `backup_jobs` tables, backup/restore with checksums, "last owner" protection, receipt storage buckets.
Suggested order: forms for trips and customers, then enrolments and payments (UI calling `record_payment`), then PDFs (reuse the prototype layout), reports, backups, Android.
