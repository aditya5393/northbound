# Accounting assumptions (implemented in packages/business and enforced again in the database)
- All money is integer paise. Booking value = price - discount; it is not cash collected.
- Net received = payments - refunds. Outstanding (confirmed booking) = booking value - net received. Overpayments are rejected.
- A booking is "paid in full" (green PAID stamp) only when the real ledger balance is exactly zero and the booking value is above zero.
- Cancelled booking: nothing more is owed; recognized revenue = net money kept (0 if fully refunded). Cancellation fees are modelled as money kept.
- Trip profit = recognized revenue - expenses assigned to that trip. Expenses with no trip are company-wide and are never deducted from a trip's profit.
- Cash collected in a period and revenue attributable to a trip are different numbers and are reported separately.
- The payments table is append-only. Corrections are new refund entries. Writes go through `record_payment()` which locks the booking row, validates the balance, is idempotent (`idempotency_key`) and writes an audit log.
