-- Run after the migration on a database with the stub (or real) auth schema. Raises an error on any failed assertion.
create or replace function pg_temp.as_user(uid uuid, mail text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'email', mail)::text, true);
  execute 'set local role authenticated';
end $$;
create or replace function pg_temp.fails(sql text) returns boolean language plpgsql as $$
begin execute sql; return false; exception when others then return true; end $$;
create or replace function pg_temp.must(ok boolean, label text) returns void language plpgsql as $$
begin if not ok then raise exception 'FAILED: %', label; end if; raise notice 'PASS: %', label; end $$;

do $$
declare
  ca uuid := gen_random_uuid(); cb uuid := gen_random_uuid();
  ua uuid := gen_random_uuid(); ub uuid := gen_random_uuid(); uc uuid := gen_random_uuid(); us uuid := gen_random_uuid(); um uuid := gen_random_uuid();
  ta uuid := gen_random_uuid(); tb uuid := gen_random_uuid(); cua uuid := gen_random_uuid(); cub uuid := gen_random_uuid();
  ea uuid := gen_random_uuid(); eb uuid := gen_random_uuid(); n int; p1 uuid; p2 uuid;
begin
  -- setup as superuser: two companies, owner invitations (the provisioning path), outsiders
  insert into auth.users (id, email) values (ua, 'owner.a@example.com'), (ub, 'owner.b@example.com'), (uc, 'random@gmail.com'), (us, 'staff@example.com'), (um, 'mgr@example.com');
  perform pg_temp.must((select count(*) from public.profiles) = 5, 'profile created for every new user');
  insert into public.companies (id, name) values (ca, 'Company A'), (cb, 'Company B');
  insert into public.invitations (company_id, email, role) values (ca, 'owner.a@example.com', 'owner'), (cb, 'owner.b@example.com', 'owner'), (ca, 'staff@example.com', 'staff');
  insert into public.trips (id, company_id, name) values (ta, ca, 'A trip'), (tb, cb, 'B trip');
  insert into public.customers (id, company_id, full_name, phone) values (cua, ca, 'Cust A', '9876543210'), (cub, cb, 'Cust B', '9876543210');
  insert into public.enrollments (id, company_id, trip_id, customer_id, booking_price_paise) values (ea, ca, ta, cua, 100000), (eb, cb, tb, cub, 100000);

  perform pg_temp.as_user(uc, 'random@gmail.com');
  perform pg_temp.must((select public.accept_pending_invitations()) = 0, 'random Google account gets no access');
  perform pg_temp.must((select count(*) from public.trips) = 0, 'random account sees no trips');
  perform pg_temp.must(pg_temp.fails($q$ insert into public.companies (name) values ('Hack') $q$), 'random account cannot create a company');
  reset role;

  perform pg_temp.as_user(ua, 'owner.a@example.com');
  perform pg_temp.must((select public.accept_pending_invitations()) = 1, 'owner invitation becomes membership');
  perform pg_temp.must((select role from public.memberships where user_id = ua) = 'owner', 'first owner is owner');
  perform pg_temp.must((select count(*) from public.trips) = 1 and (select name from public.trips) = 'A trip', 'owner A sees only company A trips');
  perform pg_temp.must((select count(*) from public.enrollments where company_id = cb) = 0, 'owner A cannot read company B bookings');
  perform pg_temp.must(pg_temp.fails(format($q$ insert into public.trips (company_id, name) values (%L, 'Sneaky') $q$, cb)), 'owner A cannot write into company B');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 100, 'payment', 'cash') $q$, eb)), 'owner A cannot record a payment on company B booking');
  perform pg_temp.must(pg_temp.fails($q$ update public.companies set name = 'x' where name = 'Company B' $q$) or (select count(*) from public.companies) = 1, 'owner A cannot see or edit company B');
  p1 := public.record_payment(ea, 40000, 'payment', 'upi', 'UPI-1', 'key-1');
  p2 := public.record_payment(ea, 40000, 'payment', 'upi', 'UPI-1', 'key-1');
  perform pg_temp.must(p1 = p2 and (select count(*) from public.payments where enrollment_id = ea) = 1, 'same idempotency key does not double-book');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 40000, 'payment', 'upi', 'UPI-1') $q$, ea)), 'duplicate reference number rejected');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 70000, 'payment', 'cash') $q$, ea)), 'overpayment rejected');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 50000, 'refund', 'cash') $q$, ea)), 'refund above net received rejected');
  perform public.record_payment(ea, 60000, 'payment', 'cash');
  perform pg_temp.must((select sum(amount_paise) from public.payments where enrollment_id = ea) = 100000, 'multiple payments settle the booking');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 1, 'payment', 'cash') $q$, ea)), 'fully paid booking takes no more payments');
  perform pg_temp.must(pg_temp.fails(format($q$ insert into public.payments (company_id, enrollment_id, amount_paise, transaction_type, payment_method) values (%L, %L, 5, 'payment', 'cash') $q$, ca, ea)), 'client cannot insert ledger rows directly');
  perform pg_temp.must(pg_temp.fails($q$ update public.payments set amount_paise = 1 $q$) and pg_temp.fails($q$ delete from public.payments $q$), 'ledger is append-only for clients');
  perform pg_temp.must((select count(*) from public.audit_logs where entity_type = 'payment') = 2, 'payments are audit-logged');
  perform pg_temp.must(pg_temp.fails(format($q$ insert into public.enrollments (company_id, trip_id, customer_id, booking_price_paise) values (%L, %L, %L, 1) $q$, ca, ta, cua)), 'duplicate enrolment in same trip rejected');
  perform pg_temp.must(pg_temp.fails(format($q$ insert into public.enrollments (company_id, trip_id, customer_id, booking_price_paise) values (%L, %L, %L, 1) $q$, ca, tb, cua)), 'cannot mix company A customer with company B trip');
  insert into public.invitations (company_id, email, role, invited_by) values (ca, 'mgr@example.com', 'manager', ua);
  reset role;

  perform pg_temp.as_user(um, 'mgr@example.com');
  perform pg_temp.must((select public.accept_pending_invitations()) = 1 and (select role from public.memberships where user_id = um) = 'manager', 'invited manager joins as manager');
  perform pg_temp.must(pg_temp.fails($q$ insert into public.invitations (company_id, email, role) select company_id, 'x@y.com', 'owner' from public.memberships limit 1 $q$), 'manager cannot invite owners');
  reset role;

  perform pg_temp.as_user(us, 'staff@example.com');
  perform public.accept_pending_invitations();
  perform pg_temp.must((select count(*) from public.trips) = 1, 'staff can read company trips');
  perform pg_temp.must(pg_temp.fails(format($q$ insert into public.trips (company_id, name) values (%L, 'Staff trip') $q$, ca)), 'staff cannot create trips');
  perform pg_temp.must(pg_temp.fails(format($q$ select public.record_payment(%L, 1, 'refund', 'cash') $q$, ea)), 'staff cannot record ledger entries');
  perform pg_temp.must((select count(*) from public.audit_logs) = 0, 'staff cannot read audit logs');
  reset role;

  perform pg_temp.as_user(ub, 'owner.b@example.com');
  perform public.accept_pending_invitations();
  perform pg_temp.must((select count(*) from public.payments) = 0 and (select count(*) from public.trips) = 1, 'owner B sees none of company A money');
  reset role;
  raise notice 'ALL DATABASE CHECKS PASSED';
end $$;
