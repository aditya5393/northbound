-- NorthBound core schema, tenant isolation (RLS) and trusted ledger functions.
-- Source of truth for the database. Money is integer paise. Every business row carries company_id.

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) > 0),
  logo_path text,
  currency_code text not null default 'INR' check (currency_code = 'INR'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text, email text, avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','manager','staff')),
  status text not null default 'active' check (status in ('active','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, user_id)
);
create index on public.memberships (user_id);

-- Invitations are the ONLY way to get access. The first owner is provisioned by inserting an 'owner' invitation (docs/provisioning.sql).
create table public.invitations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null check (email = lower(email) and position('@' in email) > 1),
  role text not null check (role in ('owner','manager','staff')),
  status text not null default 'pending' check (status in ('pending','accepted','revoked')),
  invited_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  accepted_at timestamptz
);
create unique index on public.invitations (company_id, email) where status = 'pending';

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null check (length(trim(name)) > 0),
  destination text,
  start_date date, end_date date,
  status text not null default 'open' check (status in ('open','completed','archived')),
  capacity integer check (capacity > 0),
  created_by uuid references auth.users(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_date is null or start_date is null or end_date >= start_date),
  unique (id, company_id)
);
create index on public.trips (company_id, start_date desc);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  full_name text not null check (length(trim(full_name)) > 0),
  phone text not null check (phone ~ '^[6-9][0-9]{9}$'),  -- 10-digit Indian mobile, stored without +91
  email text, emergency_contact text, notes text,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, phone),
  unique (id, company_id)
);

create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  trip_id uuid not null, customer_id uuid not null,
  booking_price_paise bigint not null check (booking_price_paise >= 0),
  discount_paise bigint not null default 0 check (discount_paise >= 0),
  booking_status text not null default 'confirmed' check (booking_status in ('confirmed','cancelled')),
  booked_at timestamptz not null default now(),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (discount_paise <= booking_price_paise),
  unique (trip_id, customer_id),               -- no duplicate enrolment in the same trip
  unique (id, company_id),
  foreign key (trip_id, company_id) references public.trips (id, company_id),
  foreign key (customer_id, company_id) references public.customers (id, company_id)
);
create index on public.enrollments (company_id, trip_id);

-- Append-only ledger: no update/delete, inserts only through record_payment().
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  enrollment_id uuid not null,
  amount_paise bigint not null check (amount_paise > 0),
  transaction_type text not null check (transaction_type in ('payment','refund')),
  payment_method text not null check (payment_method in ('upi','cash','bank_transfer','card','cheque','other')),
  reference_number text,
  idempotency_key text,
  paid_at timestamptz not null default now(),
  recorded_by uuid references auth.users(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  foreign key (enrollment_id, company_id) references public.enrollments (id, company_id),
  unique (company_id, idempotency_key)
);
create unique index on public.payments (enrollment_id, transaction_type, reference_number) where reference_number is not null;
create index on public.payments (company_id, enrollment_id);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  trip_id uuid,  -- null = company-wide expense, never counted against a trip's profit
  category text not null check (category in ('vehicles','hotels','camps','food','activities','permits','other_facilities','miscellaneous')),
  vendor_name text, description text,
  amount_paise bigint not null check (amount_paise > 0),
  expense_date date not null default current_date,
  payment_method text, receipt_path text,
  recorded_by uuid references auth.users(id) on delete set null,
  voided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  foreign key (trip_id, company_id) references public.trips (id, company_id)
);
create index on public.expenses (company_id, trip_id);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  actor_user_id uuid, entity_type text not null, entity_id uuid, action text not null,
  before_data jsonb, after_data jsonb,
  created_at timestamptz not null default now()
);
create index on public.audit_logs (company_id, created_at desc);

do $$ declare t text; begin
  foreach t in array array['companies','profiles','memberships','trips','customers','enrollments','expenses'] loop
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- Authorization helpers (security definer so policies on memberships cannot recurse).
create function public.is_member(cid uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.memberships m where m.company_id = cid and m.user_id = auth.uid() and m.status = 'active') $$;
create function public.has_role(cid uuid, roles text[]) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.memberships m where m.company_id = cid and m.user_id = auth.uid() and m.status = 'active' and m.role = any (roles)) $$;
create function public.shares_company(other uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.memberships a join public.memberships b on a.company_id = b.company_id
                 where a.user_id = auth.uid() and a.status = 'active' and b.user_id = other) $$;

-- Create a profile row for every new Google sign-in. This grants NO company access.
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (user_id, email, full_name, avatar_url)
  values (new.id, new.email, new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'avatar_url')
  on conflict (user_id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Turns pending invitations for the signed-in user's verified email into memberships.
create function public.accept_pending_invitations() returns integer language plpgsql security definer set search_path = '' as $$
declare n integer := 0; inv record; mail text := lower(auth.jwt() ->> 'email');
begin
  if auth.uid() is null or mail is null then return 0; end if;
  for inv in select * from public.invitations where email = mail and status = 'pending' for update loop
    insert into public.memberships (company_id, user_id, role) values (inv.company_id, auth.uid(), inv.role)
      on conflict (company_id, user_id) do update set role = excluded.role, status = 'active';
    update public.invitations set status = 'accepted', accepted_at = now() where id = inv.id;
    insert into public.audit_logs (company_id, actor_user_id, entity_type, entity_id, action, after_data)
      values (inv.company_id, auth.uid(), 'invitation', inv.id, 'accepted', jsonb_build_object('role', inv.role));
    n := n + 1;
  end loop;
  return n;
end $$;

-- The only way to write the ledger. Locks the booking row, validates against the real balance, is idempotent.
create function public.record_payment(p_enrollment_id uuid, p_amount_paise bigint, p_type text, p_method text,
  p_reference text default null, p_idempotency_key text default null, p_notes text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare e public.enrollments; net bigint; due bigint; pid uuid;
begin
  select * into e from public.enrollments where id = p_enrollment_id for update;
  if not found or not public.has_role(e.company_id, array['owner','manager']) then raise exception 'not authorized'; end if;
  if p_idempotency_key is not null then
    select id into pid from public.payments where company_id = e.company_id and idempotency_key = p_idempotency_key;
    if found then return pid; end if;
  end if;
  if p_amount_paise is null or p_amount_paise <= 0 then raise exception 'amount must be greater than zero'; end if;
  select coalesce(sum(case transaction_type when 'refund' then -amount_paise else amount_paise end), 0) into net
    from public.payments where enrollment_id = e.id;
  if p_type = 'payment' then
    if e.booking_status = 'cancelled' then raise exception 'cancelled bookings cannot take payments'; end if;
    due := e.booking_price_paise - e.discount_paise - net;
    if p_amount_paise > due then raise exception 'overpayment blocked: remaining balance is % paise', due; end if;
  elsif p_type = 'refund' then
    if p_amount_paise > net then raise exception 'refund exceeds net amount received'; end if;
  else raise exception 'invalid transaction type'; end if;
  insert into public.payments (company_id, enrollment_id, amount_paise, transaction_type, payment_method, reference_number, idempotency_key, recorded_by, notes)
    values (e.company_id, e.id, p_amount_paise, p_type, p_method, nullif(trim(p_reference), ''), p_idempotency_key, auth.uid(), p_notes)
    returning id into pid;
  insert into public.audit_logs (company_id, actor_user_id, entity_type, entity_id, action, after_data)
    values (e.company_id, auth.uid(), 'payment', pid, p_type, jsonb_build_object('enrollment_id', e.id, 'amount_paise', p_amount_paise, 'method', p_method));
  return pid;
end $$;

-- Row Level Security
do $$ declare t text; begin
  foreach t in array array['companies','profiles','memberships','invitations','trips','customers','enrollments','payments','expenses','audit_logs'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
  end loop;
end $$;

grant select, update on public.companies to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.memberships, public.invitations to authenticated;
grant select, insert, update on public.trips, public.customers, public.enrollments, public.expenses to authenticated;
grant select on public.payments, public.audit_logs to authenticated;

create policy companies_select on public.companies for select to authenticated using (public.is_member(id));
create policy companies_update on public.companies for update to authenticated using (public.has_role(id, array['owner'])) with check (public.has_role(id, array['owner']));
create policy profiles_select on public.profiles for select to authenticated using (user_id = auth.uid() or public.shares_company(user_id));
create policy profiles_update on public.profiles for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy memberships_select on public.memberships for select to authenticated using (user_id = auth.uid() or public.is_member(company_id));
create policy memberships_write on public.memberships for all to authenticated using (public.has_role(company_id, array['owner'])) with check (public.has_role(company_id, array['owner']));
create policy invitations_owner on public.invitations for all to authenticated using (public.has_role(company_id, array['owner'])) with check (public.has_role(company_id, array['owner']));

do $$ declare t text; begin
  foreach t in array array['trips','customers','enrollments','expenses'] loop
    execute format('create policy %I on public.%I for select to authenticated using (public.is_member(company_id))', t || '_select', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (public.has_role(company_id, array[''owner'',''manager'']))', t || '_insert', t);
    execute format('create policy %I on public.%I for update to authenticated using (public.has_role(company_id, array[''owner'',''manager''])) with check (public.has_role(company_id, array[''owner'',''manager'']))', t || '_update', t);
  end loop;
end $$;
create policy payments_select on public.payments for select to authenticated using (public.is_member(company_id));
create policy audit_select on public.audit_logs for select to authenticated using (public.has_role(company_id, array['owner','manager']));

revoke all on function public.record_payment(uuid, bigint, text, text, text, text, text) from public, anon;
revoke all on function public.accept_pending_invitations() from public, anon;
grant execute on function public.record_payment(uuid, bigint, text, text, text, text, text) to authenticated;
grant execute on function public.accept_pending_invitations() to authenticated;
