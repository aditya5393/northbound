-- DEVELOPMENT ONLY seed data. Never run against production.
insert into public.companies (id, name) values ('00000000-0000-0000-0000-00000000d001', 'DEV NorthBound Demo Co');
insert into public.trips (id, company_id, name, destination, start_date, end_date, status) values
 ('00000000-0000-0000-0000-0000000a0001', '00000000-0000-0000-0000-00000000d001', 'Spiti Valley Expedition', 'Spiti, Himachal Pradesh', '2026-09-05', '2026-09-12', 'completed'),
 ('00000000-0000-0000-0000-0000000a0002', '00000000-0000-0000-0000-00000000d001', 'Rajasthan Heritage Tour', 'Jaipur to Udaipur', '2026-11-14', '2026-11-20', 'open');
insert into public.customers (id, company_id, full_name, phone) values
 ('00000000-0000-0000-0000-0000000c0001', '00000000-0000-0000-0000-00000000d001', 'Aarav Mehta', '9876543210'),
 ('00000000-0000-0000-0000-0000000c0002', '00000000-0000-0000-0000-00000000d001', 'Priya Nair', '9988776655');
insert into public.enrollments (id, company_id, trip_id, customer_id, booking_price_paise, discount_paise) values
 ('00000000-0000-0000-0000-0000000e0001', '00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000a0001', '00000000-0000-0000-0000-0000000c0001', 4500000, 0),
 ('00000000-0000-0000-0000-0000000e0002', '00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000a0002', '00000000-0000-0000-0000-0000000c0002', 3800000, 300000);
insert into public.payments (company_id, enrollment_id, amount_paise, transaction_type, payment_method, reference_number) values
 ('00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000e0001', 2000000, 'payment', 'upi', 'UPI-4821'),
 ('00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000e0001', 2500000, 'payment', 'bank_transfer', 'NEFT-7730'),
 ('00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000e0002', 3500000, 'payment', 'card', 'CARD-9981');
insert into public.expenses (company_id, trip_id, category, vendor_name, amount_paise) values
 ('00000000-0000-0000-0000-00000000d001', '00000000-0000-0000-0000-0000000a0001', 'vehicles', 'Himalayan Cabs', 2800000),
 ('00000000-0000-0000-0000-00000000d001', null, 'miscellaneous', 'Office rent', 1800000);
