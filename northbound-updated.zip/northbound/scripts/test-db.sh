#!/usr/bin/env bash
# Applies migrations + dev seed to a THROWAWAY Postgres and runs the RLS/ledger tests.
# Usage: PGHOST=localhost PGUSER=postgres PGPASSWORD=postgres bash scripts/test-db.sh
set -euo pipefail
DB="northbound_test_$$"
psql -v ON_ERROR_STOP=1 -q -d postgres -c "create database $DB"
trap 'psql -q -d postgres -c "drop database if exists $DB" >/dev/null' EXIT
export PGDATABASE="$DB"
psql -v ON_ERROR_STOP=1 -q -f supabase/tests/00_stub_auth.sql
for f in supabase/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -q -f "$f"; done
psql -v ON_ERROR_STOP=1 -q -f supabase/seed.sql
psql -v ON_ERROR_STOP=1 -f supabase/tests/10_rls_and_ledger.sql 2>&1 | grep -E "PASS|FAILED|ERROR|ALL DATABASE" 
